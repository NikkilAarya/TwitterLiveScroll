//
//  ViewController.swift
//  ScrollScreensDemo
//
//  Created by Apple on 05/07/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var contentScrollView: UIScrollView!
    @IBOutlet weak var contentViewOf_ContentScrollView: UIView!
    
    @IBOutlet weak var tabsScrollView: UIScrollView!
    @IBOutlet weak var sliderView: UIView!
    @IBOutlet var sliderViewLeading: NSLayoutConstraint!
    
    @IBOutlet weak var widthOfSliderView: NSLayoutConstraint!
    var silderViewWidth:CGFloat = 0
    
    let buttonPadding:CGFloat = 20
    var xOffset:CGFloat = 10
    var horizontalSlideViewConstraint:NSLayoutConstraint?
    
    
    var mainScrollViewOffsetX:CGFloat = 0
    
    var tabButtons:[UIButton] = []
    
    private lazy var stackView: UIStackView = {
      let stackView = UIStackView()
      stackView.axis = .horizontal
        stackView.alignment = .fill
        stackView.distribution = .fillEqually
      stackView.spacing = 0
      stackView.translatesAutoresizingMaskIntoConstraints = false
      return stackView
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
      
    }
    override func viewWillAppear(_ animated: Bool) {
       
        addTabsToVC()
    }
  
    func setUpCOnstraintsForStackView(){
        
        NSLayoutConstraint.activate([
          stackView.topAnchor.constraint(equalTo: contentScrollView.topAnchor),
          stackView.rightAnchor.constraint(equalTo: contentScrollView.rightAnchor),
          stackView.bottomAnchor.constraint(equalTo: contentScrollView.bottomAnchor),
          stackView.leftAnchor.constraint(equalTo: contentScrollView.leftAnchor)
        ])
    }
    func getRandomColor() -> UIColor{
        let randomRed = CGFloat.random(in: 0...1)
        let randomGreen = CGFloat.random(in: 0...1)
        let randomBlue = CGFloat.random(in: 0...1)
        return UIColor(red: randomRed, green: randomGreen, blue: randomBlue, alpha: 1.0)
    }
    func addTabsToVC(){
        
        let contentView  = UIView(frame: CGRect(x: 0, y: 0, width: 8 * (xOffset + buttonPadding + 50 ), height: contentScrollView.frame.height))
        tabsScrollView.addSubview(contentView)
        tabsScrollView.contentSize = CGSize(width: 8 * (xOffset + buttonPadding + 50 ), height: tabsScrollView.frame.height)
        
        silderViewWidth = 10 + (buttonPadding/2) + 50
        widthOfSliderView.constant = silderViewWidth
     

        for i in 0 ... 8 {
            
            
            let view = UIView(frame: CGRect(x: mainScrollViewOffsetX, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height))
            view.backgroundColor = .random()
            
            contentViewOf_ContentScrollView.addSubview(view)
            mainScrollViewOffsetX +=  UIScreen.main.bounds.width
            
            
            
            let button = UIButton()
            button.tag = i
            button.backgroundColor = UIColor.darkGray
            button.setTitle("\(i)", for: .normal)
            button.addTarget(self, action:#selector(self.buttonClicked), for: .touchUpInside)
            tabButtons.append(button)
            
            button.frame = CGRect(x: xOffset, y: 25, width: 50, height: tabsScrollView.bounds.height - 25 )
            
            
            xOffset = xOffset + CGFloat(buttonPadding) + button.frame.size.width
            contentView.addSubview(button)
            
            
        }
        scrollViewDidEndDecelerating(contentScrollView)

    }
    @objc  func buttonClicked(_ sender: UIButton) {
        let index:CGFloat = CGFloat (  sender.tag  )
        contentScrollView.setContentOffset(CGPoint(x: index * contentScrollView.bounds.width, y: 0), animated: true)


    }
    
    @IBAction func buttonScrollAction(_ sender: Any) {
        let index:CGFloat = CGFloat (  (sender as? UIButton)!.tag  )
        contentScrollView.setContentOffset(CGPoint(x: index * contentScrollView.bounds.width, y: 0), animated: true)
        UIView.animate(withDuration: 0.4, animations: {
            self.sliderViewLeading.constant = CGFloat(index) * self.silderViewWidth
            self.view.layoutIfNeeded()
        })

    }
    

}

extension ViewController:UIScrollViewDelegate{

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
  
        horizontalSlideViewConstraint?.isActive = false
        self.sliderViewLeading.isActive = true

        let mainPercentage =  scrollView.contentOffset.x / UIScreen.main.bounds.width
        let slideValue = (silderViewWidth ) * mainPercentage
        self.sliderViewLeading.constant = slideValue/2
        
        tabsScrollView.setContentOffset(CGPoint(x: slideValue/2 , y: tabsScrollView.contentOffset.y) , animated: false)
      }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        print("end")
        let index = Int(scrollView.contentOffset.x / scrollView.bounds.size.width)
        let tabButton = tabButtons[index]
        self.sliderViewLeading.isActive = false

        horizontalSlideViewConstraint = NSLayoutConstraint(item: sliderView, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: tabButton, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1, constant: 0)
        horizontalSlideViewConstraint?.isActive = true


    }
    
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        scrollViewDidEndDecelerating(scrollView)

    }
    
}



extension CGFloat {
    static func random() -> CGFloat {
        return CGFloat(arc4random()) / CGFloat(UInt32.max)
    }
}

extension UIColor {
    static func random() -> UIColor {
        return UIColor(red:   .random(),
                       green: .random(),
                       blue:  .random(),
                       alpha: 1.0)
    }
}
