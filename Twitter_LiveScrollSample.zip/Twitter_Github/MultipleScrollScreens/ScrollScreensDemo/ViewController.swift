//
//  ViewController.swift
//  ScrollScreensDemo
//
//  Created by Apple on 05/07/21.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var sliderView: UIView!
    @IBOutlet weak var sliderViewLeading: NSLayoutConstraint!
    
    var silderViewWidth:CGFloat = 0
    
    @IBOutlet weak var videoTableView: UITableView!
    
    var videoData:[[String:Any]]?
    
    lazy var avPlayer : AVPlayer = {
        let player = AVPlayer()
        return player
    }()

    lazy var avPlayerLayer : AVPlayerLayer = {
        let layer = AVPlayerLayer(player: self.avPlayer)
        return layer
    }()
    var avPlayerRateObserver: NSKeyValueObservation?

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        videoTableView.decelerationRate = .fast
        videoTableView.isPagingEnabled = true
       // controlAvPlayer()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        if let path = Bundle.main.path(forResource: "VideoData", ofType: "rtf") {
            do {
                  let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                  let jsonResult = try JSONSerialization.jsonObject(with: data, options: .mutableLeaves)
                if let jsonResult = jsonResult as? Dictionary<String, AnyObject>, let jsondata = (jsonResult["categories"] as? [Any])?[0] as? [String:Any] {
                            // do stuff
                    videoData = jsondata["videos"] as? [[String : Any]]
                    if videoData?.count ?? 0 > 0 {
                      //  print(videoData)
                        videoTableView.reloadData()
                    }
                  }
              } catch {
                print(error)
                   // handle error
              }
        }

    }
    override func viewDidAppear(_ animated: Bool) {
        silderViewWidth = sliderView.bounds.width

    }
    
    @IBAction func buttonScrollAction(_ sender: Any) {
        let index:CGFloat = CGFloat (  (sender as? UIButton)!.tag  )
        scrollView.setContentOffset(CGPoint(x: index * scrollView.bounds.width, y: 0), animated: true)
        UIView.animate(withDuration: 0.4, animations: {
            self.sliderViewLeading.constant = CGFloat(index) * self.silderViewWidth
            self.view.layoutIfNeeded()
        })

    }
    

}

extension ViewController:UIScrollViewDelegate{
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        if scrollView == videoTableView {return}
        
         
        let index = Int(scrollView.contentOffset.x / scrollView.bounds.size.width)
        UIView.animate(withDuration: 0.4, animations: {
            self.sliderViewLeading.constant = CGFloat(index) * self.silderViewWidth
            self.view.layoutIfNeeded()
        })
    }
}
