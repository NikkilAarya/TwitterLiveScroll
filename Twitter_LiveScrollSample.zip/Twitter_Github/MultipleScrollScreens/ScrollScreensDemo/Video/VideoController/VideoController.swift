//
//  VideoController.swift
//  ScrollScreensDemo
//
//  Created by Apple on 07/07/21.
//

import Foundation
import AVFoundation
import UIKit

extension ViewController {
    
    private func removePlayerFromCell()
    {
        if (self.avPlayerLayer.superlayer != nil)
        {
            self.avPlayerLayer.removeFromSuperlayer()
            self.avPlayer.pause()
            self.avPlayer.replaceCurrentItem(with: nil)
        }
    }
    private func attachPlayerToCell(indexPath : IndexPath)
    {
        if let cell = videoTableView.cellForRow(at: indexPath) as? VideoCell
        {
           // self.removePlayerFromCell()
            if ((avPlayer.rate != 0) && (avPlayer.error == nil)) {
                // player is playing
              //  cell.playPauseButton.isSelected = true
                cell.playPauseButton.alpha = 1
                avPlayer.pause()
                return
            }else if  (self.avPlayerLayer.superlayer != nil) {
                cell.playPauseButton.alpha = 0
                avPlayer.play()
            return
            }

            
            avPlayerRateObserver = self.avPlayer.observe(\.rate, options:  [.new, .old], changeHandler: { (player, change) in
                 if player.rate == 1  {
                    cell.thumbnailImage?.alpha = 0
                    cell.playPauseButton.alpha = 0

                      print("Playing")
                  }else{
                    cell.thumbnailImage?.alpha = 1
                       print("Stop")
                  }
             })
            let url = cell.videoUrl

            let playerItem = AVPlayerItem(url: url!)
            self.avPlayer.replaceCurrentItem(with: playerItem)

            self.avPlayerLayer.frame = cell.videoView.frame
            self.avPlayerLayer.videoGravity = .resizeAspectFill

            cell.videoView.layer.addSublayer(self.avPlayerLayer)
            self.avPlayer.play()
            
          

        }
    }
    
//    func controlAvPlayer(){
//
//
//    }

    
}

extension ViewController: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return videoData?.count ?? 0
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.bounds.height //400
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "CoreVideoTableCell") as? VideoCell
        if cell == nil {
            cell = VideoCell(style: .default, reuseIdentifier: "CoreVideoTableCell")
        }
    
       // cell?.videoView.backgroundColor = .red
        cell?.playPauseButton.alpha = 1
        cell?.thumbnailImage.alpha = 1

        cell?.videoData = videoData?[indexPath.row]
        return cell!
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       // let cell = tableView.cellForRow(at: indexPath) as! CoreVideoTableCell
       // cell.videoUrl
       // cell.videoPlayer?.play()
        attachPlayerToCell(indexPath: indexPath)

    }
    func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {
//            guard let videoCell = cell as? CoreVideoTableCell else { return };
//        videoCell.videoView.backgroundColor = .blue
        self.removePlayerFromCell()


//
//            videoCell.videoPlayer?.pause();
           // videoCell.videoLayer?.removeFromSuperlayer()
        }


}
