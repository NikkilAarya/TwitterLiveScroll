//
//  VideoCell.swift
//  ScrollScreensDemo
//
//  Created by Apple on 07/07/21.
//

import UIKit

class VideoCell: UITableViewCell {

    @IBOutlet weak var videoView: UIView!
    @IBOutlet weak var thumbnailImage: UIImageView!
    let domain = "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/"
    @IBOutlet weak var playPauseButton: UIButton!

    var videoUrl:URL? = nil
    var data:Data? = nil

    
    var videoData:[String:Any]? {
        didSet{
            let url = URL(string: (videoData?["sources"] as! [String])[0] )
            videoUrl = url
            let thumburl = URL(string: "\(domain)\(videoData!["thumb"] as! String)")
            if let data = try? Data(contentsOf: thumburl!){
                thumbnailImage.image = UIImage(data: data)
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
